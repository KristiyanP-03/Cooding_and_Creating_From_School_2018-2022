﻿using System;

namespace StudentSystem_KP
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
